/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Zombie extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Zombie/costumes/costume1.svg", {
        x: 25,
        y: 25
      }),
      new Costume("costume2", "./Zombie/costumes/costume2.svg", {
        x: 25,
        y: 25
      }),
      new Costume("costume3", "./Zombie/costumes/costume3.svg", {
        x: 25,
        y: 25
      })
    ];

    this.sounds = [new Sound("pop", "./Zombie/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(Trigger.BROADCAST, { name: "Mag" }, this.whenIReceiveMag),
      new Trigger(
        Trigger.BROADCAST,
        { name: "message1" },
        this.whenIReceiveMessage1
      )
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.vars.zombiemult = 5;
    this.stage.vars.zombies = 0;
    this.visible = false;
    for (let i = 0; i < this.toNumber(this.stage.vars.zombiemult); i++) {
      this.createClone();
      this.stage.vars.zombies++;
      yield;
    }
  }

  *startAsClone() {
    this.visible = true;
    this.goto(this.random(-180, 180), 200);
    while (true) {
      this.direction = this.radToScratch(
        Math.atan2(
          this.sprites["Player"].y - this.y,
          this.sprites["Player"].x - this.x
        )
      );
      this.move(2);
      yield;
    }
  }

  *startAsClone2() {
    this.costume = "costume1";
    while (true) {
      if (this.touching(this.sprites["Bullet"].andClones())) {
        while (!!this.touching(this.sprites["Bullet"].andClones())) {
          yield;
        }
        this.costumeNumber++;
      }
      yield;
    }
  }

  *startAsClone3() {
    while (true) {
      if (this.touching(this.sprites["Bullet"].andClones())) {
        if (this.costumeNumber === 3) {
          if (this.touching(this.sprites["Bullet"].andClones())) {
            this.stage.vars.zombies--;
            this.stage.vars.points++;
            this.deleteThisClone();
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveMag() {
    this.stage.vars.zombiemult =
      this.toNumber(this.stage.vars.zombiemult) * 1.2;
    for (let i = 0; i < this.toNumber(this.stage.vars.zombiemult); i++) {
      this.createClone();
      this.stage.vars.zombies++;
      yield;
    }
  }

  *whenIReceiveMessage1() {
    this.stage.vars.zombiemult =
      this.toNumber(this.stage.vars.zombiemult) * 1.2;
    for (let i = 0; i < this.toNumber(this.stage.vars.zombiemult); i++) {
      this.createClone();
      this.stage.vars.zombies++;
      yield;
    }
  }
}
