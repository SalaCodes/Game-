/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bullet extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Bullet/costumes/costume1.svg", {
        x: 11.391490000000005,
        y: 3.604440000000011
      })
    ];

    this.sounds = [
      new Sound("1911-reload-6248", "./Bullet/sounds/1911-reload-6248.wav"),
      new Sound(
        "9mm-pistol-shoot-short-reverb-7152",
        "./Bullet/sounds/9mm-pistol-shoot-short-reverb-7152.wav"
      )
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.BROADCAST, { name: "Mag" }, this.whenIReceiveMag)
    ];

    this.vars.bullmult = 15;
  }

  *whenGreenFlagClicked() {
    this.vars.bullmult = 3;
    while (true) {
      if (this.toNumber(this.stage.vars.bullets) === 0) {
        if (this.keyPressed("space")) {
          this.say("Reloading...");
          for (let i = 0; i < this.toNumber(this.vars.bullmult); i++) {
            yield* this.startSound("1911-reload-6248");
            this.stage.vars.bullets++;
            yield* this.wait(1);
            yield;
          }
          yield* this.sayAndWait("Reloaded", 2);
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.bullets = 3;
    while (true) {
      if (!(this.toNumber(this.stage.vars.bullets) === 0)) {
        if (this.mouse.down) {
          this.createClone();
          while (!!this.mouse.down) {
            yield;
          }
        }
      } else {
        null;
      }
      yield;
    }
  }

  *startAsClone() {
    this.visible = true;
    if (!(this.toNumber(this.stage.vars.bullets) === 0)) {
      this.stage.vars.bullets--;
      this.costume = "bullets_PNG35544";
      yield* this.startSound("9mm-pistol-shoot-short-reverb-7152");
      while (true) {
        if (!this.touching("edge")) {
          while (!this.touching("edge")) {
            this.move(10);
            yield;
          }
        }
        if (this.touching("edge")) {
          this.deleteThisClone();
        }
        yield;
      }
    } else {
      null;
    }
  }

  *whenGreenFlagClicked3() {
    this.visible = false;
    while (true) {
      this.direction = this.radToScratch(
        Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x)
      );
      this.goto(this.sprites["R1"].x, this.sprites["R1"].y);
      yield;
    }
  }

  *whenIReceiveMag() {
    this.vars.bullmult++;
  }
}
