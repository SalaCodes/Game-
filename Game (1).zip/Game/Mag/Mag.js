/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Mag extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Mag/costumes/costume1.svg", {
        x: 47.91666499999994,
        y: 47.91665999999998
      })
    ];

    this.sounds = [new Sound("pop", "./Mag/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "message1" },
        this.whenIReceiveMessage1
      ),
      new Trigger(Trigger.BROADCAST, { name: "Mag" }, this.whenIReceiveMag)
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(182, 66);
    this.visible = false;
    yield* this.wait(1);
    while (true) {
      if (this.toNumber(this.stage.vars.zombies) === 0) {
        this.visible = true;
        if (this.touching(this.sprites["Bullet"].andClones())) {
          this.broadcast("Mag");
        }
      }
      yield;
    }
  }

  *whenIReceiveMessage1() {
    this.visible = false;
  }

  *whenIReceiveMag() {
    this.visible = false;
  }
}
