/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Player/costumes/costume1.svg", {
        x: 53.75,
        y: 33
      })
    ];

    this.sounds = [new Sound("pop", "./Player/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "message1" },
        this.whenIReceiveMessage1
      )
    ];

    this.vars.health = 0;

    this.watchers.health = new Watcher({
      label: "Player: Health",
      style: "normal",
      visible: true,
      value: () => this.vars.health,
      x: 573,
      y: 180
    });
  }

  *whenGreenFlagClicked() {
    this.goto(80, 26);
    while (true) {
      this.direction = this.radToScratch(
        Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x)
      );
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.points = 0;
    while (true) {
      if (this.keyPressed("up arrow") || this.keyPressed("w")) {
        this.y += 8;
      }
      if (this.keyPressed("down arrow") || this.keyPressed("s")) {
        this.y -= 8;
      }
      if (this.keyPressed("right arrow") || this.keyPressed("d")) {
        this.x += 8;
      }
      if (this.keyPressed("left arrow") || this.keyPressed("a")) {
        this.x -= 8;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    this.vars.health = 100;
    while (true) {
      if (this.touching(this.sprites["Zombie"].andClones())) {
        this.vars.health -= 10;
        while (!!this.touching(this.sprites["Zombie"].andClones())) {
          yield;
        }
      }
      yield;
    }
  }

  *whenIReceiveMessage1() {
    this.vars.health = 100;
  }
}
