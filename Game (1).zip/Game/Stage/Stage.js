/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 240,
        y: 180
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.bullets = 4;
    this.vars.zombies = 331;
    this.vars.points = 1630;
    this.vars.zombiemult = 331.23686334746156;

    this.watchers.bullets = new Watcher({
      label: "Bullets",
      style: "normal",
      visible: true,
      value: () => this.vars.bullets,
      x: 240,
      y: 176
    });
    this.watchers.zombies = new Watcher({
      label: "Zombies",
      style: "normal",
      visible: true,
      value: () => this.vars.zombies,
      x: 240,
      y: 146
    });
  }
}
