/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class R1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("R (1)", "./R1/costumes/R (1).svg", {
        x: 17.87291666666667,
        y: 14.002720348204576
      }),
      new Costume("R (1)2", "./R1/costumes/R (1)2.svg", {
        x: 17.852614059666706,
        y: 13.987550990204568
      })
    ];

    this.sounds = [
      new Sound(
        "9mm-pistol-shoot-short-reverb-7152",
        "./R1/sounds/9mm-pistol-shoot-short-reverb-7152.wav"
      ),
      new Sound("1911-reload-6248", "./R1/sounds/1911-reload-6248.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.goto(this.sprites["Player"].x, this.sprites["Player"].y);
      this.direction = this.radToScratch(
        Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x)
      );
      this.move(50);
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (
        this.compare(this.direction, -180) < 0 ||
        this.compare(this.direction, 0) < 0
      ) {
        this.costume = "R (1)2";
      } else {
        this.costume = "R (1)";
      }
      yield;
    }
  }
}
