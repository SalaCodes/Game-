import {
  Project,
  Sprite
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Player from "./Player/Player.js";
import R1 from "./R1/R1.js";
import Music from "./Music/Music.js";
import Zombie from "./Zombie/Zombie.js";
import Bullet from "./Bullet/Bullet.js";
import Numbers from "./Numbers/Numbers.js";
import Health from "./Health/Health.js";
import Mag from "./Mag/Mag.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Player: new Player({
    x: -60,
    y: 45,
    direction: -48.945186229037574,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 8
  }),
  R1: new R1({
    x: -98.50770941541472,
    y: 76.89288816614105,
    direction: -50.367736847156124,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 6
  }),
  Music: new Music({
    x: 36,
    y: 28,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 1
  }),
  Zombie: new Zombie({
    x: 145,
    y: 190,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: false,
    layerOrder: 2
  }),
  Bullet: new Bullet({
    x: -98.50770941541472,
    y: 76.89288816614105,
    direction: -48.945186229037546,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 3
  }),
  Numbers: new Numbers({
    x: -60,
    y: 37,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 11,
    size: 100,
    visible: false,
    layerOrder: 4
  }),
  Health: new Health({
    x: -175,
    y: 66,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 5
  }),
  Mag: new Mag({
    x: 182,
    y: 66,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 7
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
